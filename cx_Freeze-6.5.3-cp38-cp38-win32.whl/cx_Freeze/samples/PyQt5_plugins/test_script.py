# import PyQt5.QtGui
#
# from PyQt5.QtWidgets import QApplication
#
# app = QApplication([])
#
# app.exec_()

print("hi")
